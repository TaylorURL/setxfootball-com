/**
 * Sunday Design System — Tailwind preset.
 *
 * Add to any Tailwind config to get the `ds-*` color utilities
 * (`bg-ds-surface`, `text-ds-text-muted`, `border-ds-border-strong`, …),
 * the Geist font stacks, the radius/shadow scales, and the motion vocabulary.
 *
 *   // tailwind.config.js
 *   module.exports = {
 *     presets: [require('@sunday/design-system/tailwind-preset.cjs')],
 *     content: [
 *       './src/**\/*.{js,jsx,ts,tsx}',
 *       './node_modules/@sunday/design-system/src/**\/*.{js,jsx}',
 *     ],
 *   }
 *
 * Colors reference CSS variables defined in `styles/tokens.css`, so they follow
 * the active `data-theme`. Because the value is a `var()`, Tailwind's `/opacity`
 * modifier is unavailable on these — use the dedicated `*-soft` / `*-softer`
 * tokens for translucency.
 */

const dsColor = (name) => `var(--ds-${name})`

module.exports = {
  theme: {
    extend: {
      colors: {
        ds: {
          bg: dsColor('bg'),
          'bg-elevated': dsColor('bg-elevated'),
          surface: dsColor('surface'),
          'surface-2': dsColor('surface-2'),
          'surface-3': dsColor('surface-3'),
          border: dsColor('border'),
          'border-strong': dsColor('border-strong'),
          'border-input': dsColor('border-input'),
          'border-hover': dsColor('border-hover'),
          text: dsColor('text'),
          'text-muted': dsColor('text-muted'),
          'text-faint': dsColor('text-faint'),
          accent: dsColor('accent'),
          'accent-bright': dsColor('accent-bright'),
          'accent-glow': dsColor('accent-glow'),
          'accent-soft': dsColor('accent-soft'),
          'accent-softer': dsColor('accent-softer'),
          'on-accent': dsColor('on-accent'),
          positive: dsColor('positive'),
          'positive-soft': dsColor('positive-soft'),
          warning: dsColor('warning'),
          'warning-soft': dsColor('warning-soft'),
          danger: dsColor('danger'),
          'danger-soft': dsColor('danger-soft'),
          violet: dsColor('violet'),
          'violet-soft': dsColor('violet-soft'),
          indigo: dsColor('indigo'),
          'indigo-soft': dsColor('indigo-soft'),
          cyan: dsColor('cyan'),
          'cyan-soft': dsColor('cyan-soft'),
          slate: dsColor('slate'),
          'slate-soft': dsColor('slate-soft'),
          overlay: dsColor('overlay'),
          'glass-fill': dsColor('glass-fill'),
          'glass-border': dsColor('glass-border'),
          'companion-contact': dsColor('companion-contact'),
          'companion-aura': dsColor('companion-aura'),
        },
      },
      fontFamily: {
        sans: ['Geist', 'Inter', 'system-ui', 'sans-serif'],
        mono: ['"Geist Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
      },
      borderRadius: {
        ds: 'var(--ds-radius-md)',
        'ds-xs': 'var(--ds-radius-xs)',
        'ds-sm': 'var(--ds-radius-sm)',
        'ds-md': 'var(--ds-radius-md)',
        'ds-lg': 'var(--ds-radius-lg)',
        'ds-xl': 'var(--ds-radius-xl)',
        'ds-2xl': 'var(--ds-radius-2xl)',
        'ds-full': 'var(--ds-radius-full)',
      },
      boxShadow: {
        'ds-sm': 'var(--ds-shadow-sm)',
        'ds-md': 'var(--ds-shadow-md)',
        'ds-lg': 'var(--ds-shadow-lg)',
        'ds-xl': 'var(--ds-shadow-xl)',
        'ds-glass': 'var(--ds-glass-shadow)',
      },
      transitionTimingFunction: {
        'ds-out': 'cubic-bezier(0.23, 1, 0.32, 1)',
        'ds-in-out': 'cubic-bezier(0.77, 0, 0.175, 1)',
        'ds-drawer': 'cubic-bezier(0.32, 0.72, 0, 1)',
        'ds-spring': 'cubic-bezier(0.34, 1.56, 0.64, 1)',
      },
      zIndex: {
        dropdown: '1000',
        sticky: '1100',
        overlay: '1200',
        modal: '1300',
        popover: '1400',
        toast: '1500',
        tooltip: '1600',
      },
      keyframes: {
        'ds-fade-up': {
          from: { opacity: '0', transform: 'translateY(6px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        'ds-pop-in': {
          from: { opacity: '0', transform: 'scale(0.96)' },
          to: { opacity: '1', transform: 'scale(1)' },
        },
        'ds-spin': {
          to: { transform: 'rotate(360deg)' },
        },
      },
      animation: {
        'ds-fade-up': 'ds-fade-up 320ms cubic-bezier(0.23, 1, 0.32, 1) backwards',
        'ds-pop-in': 'ds-pop-in 180ms cubic-bezier(0.23, 1, 0.32, 1) both',
        'ds-spin': 'ds-spin 0.7s linear infinite',
      },
    },
  },
}
